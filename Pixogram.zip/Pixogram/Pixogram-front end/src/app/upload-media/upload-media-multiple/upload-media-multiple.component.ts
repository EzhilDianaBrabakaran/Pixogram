import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upload-media-multiple',
  templateUrl: './upload-media-multiple.component.html',
  styleUrls: ['./upload-media-multiple.component.css']
})
export class UploadMediaMultipleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
